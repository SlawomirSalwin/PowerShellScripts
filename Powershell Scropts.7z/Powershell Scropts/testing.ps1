﻿function startnewjob ([string]$passingvalue){
    $datetime = Get-Date
    $windowsShell = New-Object -ComObject WScript.Shell
    $hours=0
    $minutes=0
    $passingvalue -match '(\d)h'
    if($Matches){
        [int]$hours  = $Matches[1]
    }
    $Matches=$null
    $passingvalue -match '(\d)m' 
    if($Matches){
        [int]$minutes  = $Matches[1]
    }

    $stopdate = $datetime.AddHours($hours)
    $stopdate = $stopdate.AddMinutes($minutes)
    Write-Host -ForegroundColor Green "Time of finish $stopdate"
    while([int64]$datetime.Ticks -lt [int64]$stopdate.Ticks){
    
    $windowsShell.SendKeys('+{F15}')
    Start-Sleep -Seconds 59
    $datetime = Get-Date
    }

}
startnewjob -passingvalue '8h'