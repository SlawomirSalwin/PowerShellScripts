﻿function install-package{
param (
[CmdletBinding()][Parameter(Mandatory = $true)] [string] $InstallFilePath,
                 [Parameter(Mandatory = $true)] [string[]] $ListOfServers

)
# this part is to install stuff

foreach($server in $ListOfServers){
PsExec.exe \\TargetComputer -d -s cmd /c "msiexec.exe /I "$InstallFilePath" /quiet /norestart" 

}


}