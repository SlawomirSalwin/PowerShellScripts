﻿



################################################################################################
# PSEXEC_Command_Runspaces
# Uses PSEXEC to run a command on multiple computers.  Useful when PS remoting is not enabled
# but you have admin rights.  
#
# Requires RSAT tools for the get-adcomputer command.  You could import a csv or other method
# to obtain a list of computers instead.  
################################################################################################
# Parameters
################################################################################################
#The list of computers to process

#$pclist = get-adcomputer -filter "OperatingSystem -eq 'Windows 10 Enterprise' -and Name -like 'RC-*'" -properties DNSHostName | select -ExpandProperty DNSHostName
$Throttle = 500   #number of concurrent runspaces.  The higher this is, the more memory is needed for the runspaces.  500 takes less than 1GB for this script.  
$pclist = Import-Csv -Path "c:\temp\listofservers.csv" #place where list of computers to update is held in CSV file
$softwarelocation = "\\acopfs50\websystems`$\Tools\Beyond compare\BCompare-4.4.0.25886_x64.msi" #place where software .msi file is placed
################################################################################################
# This is the script that will run in each runspace.  
################################################################################################
$scriptblock = {
    Param (
      $nothing,  #this empty variable seems to be required because if you pass a single variable, it gets corrupted.  
      $PC
    )           
    $PC = "ACOQWB65"
  if (test-connection $PC -Count 1 -ea SilentlyContinue) {  

    # Create script folders on remote computer and copy software   
    md \\$PC\c$\temp -ea SilentlyContinue
    md \\$PC\C$\temp\QA -ea SilentlyContinue
    copy $softwarelocation "\\$pc\c$\wsapps\qa" -Force

    # Run ps exec and collect output
    # 2> $null gets rid of the "starting service and other junk from the PSexec output
    $result = & C:\Temp\SW\SysinternalsSuite\PsExec.exe \\$PC -d -s cmd /c "msiexec.exe /I $InstallFilePath /quiet /norestart" 2> $null

    #remote script file from remote machine.  You could also remove folders if apropriate here. 
    remove-item \\$pc\C$\wsapps\QA\PullBIOSandLoggedOnUser.ps1 -ea SilentlyContinue

    #Parse results from single line of output.  PS does not return muliple lines of output from PSEXEC when wrapped in a job or runspace.  
    $parts = $result.split(",")
    $outobj = New-Object psobject
    $outobj | Add-Member ComputerName $PC
    $outobj | Add-Member WindowsVersion ($parts[1].split(":")[1])
    $outobj | Add-Member BiosVersion ($parts[2].split(":")[1])
    $outobj | Add-Member LoggedOnUser ($parts[3].split(":")[1])
    $outobj | Add-Member IPAddress ($parts[4].split(":")[1])
  }
  else {   #report object indicating offline status.
  $outobj = New-Object psobject
    $outobj | Add-Member ComputerName $PC
    $outobj | Add-Member WindowsVersion "Offline"
    $outobj | Add-Member BiosVersion "?"
    $outobj | Add-Member LoggedOnUser "?"
    $outobj | Add-Member IPAddress "?"
  }
  write-output $outobj
}


################################################################################################
# Main Logic
# Runspaces are much, much faster than start-job and use far less memory
# 260 computers took 4.5GB memory and > 20 minutes to process with start- job
# 260 computers took 260MB memory and < 1 minute to process with runspaces.
################################################################################################
$RunspacePool = [runspacefactory]::CreateRunspacePool(1,$Throttle)
$RunspacePool.Open()

#RSArrayList contains a link to each runspace.  Needed to track progress and obtain results later
$RSArrayList = New-Object System.Collections.ArrayList   

#Loop through each PC in the list, creating runspaces.  The runspace pool is used for multiple parallel spaces with rate control.  
foreach ($PC in $PClist) {
  $PowerShell = [powershell]::Create()
  [void]$PowerShell.AddScript($scriptblock)
  [void]$powershell.AddArgument("").AddArgument($PC)  #extra argument to avoid single argument corruption bug.  
  $PowerShell.RunspacePool = $RunspacePool

  $ThisRS = New-Object psobject
  $ThisRS | Add-Member Computer $PC
  $ThisRS | Add-Member PSInstance $PowerShell
  $thisRS | Add-Member Space ($PowerShell.BeginInvoke())  #execution starts here.
  $RSArrayList += $thisRS
  write-host "Adding $PC"
}

################################################################################################
#Progress bar to track when jobs are finished.
write-host "waiting for runspaces to finish"
while (($RSArrayList.space.iscompleted -eq $false).count -gt 0) {
  $Done = $RSArrayList.count - ($RSArrayList.space.iscompleted -eq $false).count
  if ($Done -eq 0) {$percentComplete = 0}
  else {$percentComplete = $Done / $RSArrayList.count * 100}
  write-progress -Activity "Waiting for jobs to complete" -Status (($RSArrayList.count - $Done).ToString() + "Left") -PercentComplete $percentComplete
  sleep -Seconds 1
}

################################################################################################
#collecting results and creating report object
write-host "Processing Results"

$Report = New-Object System.Collections.ArrayList
foreach ($RS in $RSArrayList) {
  $Report += $RS.PSInstance.EndInvoke($RS.Space)  #equivilant to "receive-job"
  $RS.PSInstance.Dispose()  # frees up memory.
}

$Report | ft



